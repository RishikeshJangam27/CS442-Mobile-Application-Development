package com.example.android.temperatureconverter;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;
import java.lang.*;
import android.text.method.ScrollingMovementMethod;


public class MainActivity extends AppCompatActivity {


    public double result, input2;
    public String input1 = "", str= " ";
    private EditText input;
    private TextView output, farDegree, celDegree, history;
    private RadioGroup rg;
    private RadioButton radioButton1, radioButton2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        input = findViewById(R.id.editText);
        output = findViewById(R.id.textView6);
        farDegree = findViewById(R.id.textView2);
        celDegree = findViewById(R.id.textView3);
        history = findViewById(R.id.textView5);
        radioButton1 = findViewById((R.id.radioButton1));
        radioButton2 = findViewById(R.id.radioButton2);
        rg = findViewById(R.id.radioGroup);

    }



    public void radioButton(View v)
        {
            int currentid = rg.getCheckedRadioButtonId();


            if(currentid == radioButton1.getId()) {
                farDegree.setText("Fahrenheit Degrees:");
                celDegree.setText("Celsius Degrees:");
            }

            else if(currentid == radioButton2.getId()) {
                celDegree.setText("Fahrenheit Degrees:");
                farDegree.setText("Celsius Degrees:");

            }

        }


        public void tempConvert(View v) {


            input1 = input.getText().toString();

            if(input1.isEmpty())
            Toast.makeText(this,"Enter degree to Convert", Toast.LENGTH_SHORT).show();

        else
        {
            try {
                input2 = Double.parseDouble(input1);
            } catch (Exception e) {

                Toast.makeText(this, "Enter Number", Toast.LENGTH_SHORT).show();
            }

            int currentid = rg.getCheckedRadioButtonId();
            if (currentid == radioButton1.getId()) {

                    result = (input2 - 32.0) / 1.8;
                    output.setText(String.format("% .1f", result));
                    str = input1 + " F" + " ======> " + String.format("% .1f", result) + " C" + "\n" + str;
            }
            else {
                result = (input2 * 1.8) + 32;
                output.setText(String.format("%.1f", result));
                str = input1 + " C" + " ======> " + String.format("% .1f", result) + "\tF" + "\n" + str;


            }

            history.setMovementMethod(new ScrollingMovementMethod());
            history.setText(str);
        }


        }

        public void clear(View v) {
          str = "";
         history.setText("");
        }

        @Override
    protected void onSaveInstanceState(Bundle outState)
        {
            outState.putString("History",history.getText().toString());
            outState.putString("Output",output.getText().toString());
            outState.putString("FtoC",farDegree.getText().toString());
            outState.putString("CtoF",celDegree.getText().toString());
            outState.putString("str",str);

            super.onSaveInstanceState(outState);
        }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {

        super.onRestoreInstanceState(savedInstanceState);

        history.setText(savedInstanceState.getString("History"));
        output.setText(savedInstanceState.getString("Output"));
        farDegree.setText(savedInstanceState.getString("FtoC"));
        celDegree.setText(savedInstanceState.getString("CtoF"));
        str = savedInstanceState.getString("str");

    }



}
