package com.example.knowyourgovernment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

public class AboutActivity extends AppCompatActivity {

    TextView apiURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        apiURL = findViewById(R.id.apiURL);
        final String url = "https://developers.google.com/civic-information/";
        apiURL.setText("G͟o͟o͟g͟l͟e͟ ͟C͟i͟v͟i͟c͟ ͟I͟n͟f͟o͟r͟m͟a͟t͟i͟o͟n͟ ͟A͟P͟I͟");
        apiURL.setTextColor(Color.WHITE);
        apiURL.setGravity(Gravity.CENTER);
        apiURL.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        apiURL.setTextSize(35);

        apiURL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse(url));
                startActivity(intent);
            }
        });



    }
}

