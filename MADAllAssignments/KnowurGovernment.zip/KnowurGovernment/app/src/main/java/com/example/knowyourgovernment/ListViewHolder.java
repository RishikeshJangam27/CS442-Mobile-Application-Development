package com.example.knowyourgovernment;

import android.view.View;
import android.widget.TextView;

import androidx.appcompat.view.menu.MenuView;
import androidx.recyclerview.widget.RecyclerView;

class ListViewHolder extends RecyclerView.ViewHolder {
     TextView jobName, servingName;
     ListViewHolder(View view){
        super(view);
        jobName = view.findViewById(R.id.jobName);
        servingName = view.findViewById(R.id.servingName);
    }
}
