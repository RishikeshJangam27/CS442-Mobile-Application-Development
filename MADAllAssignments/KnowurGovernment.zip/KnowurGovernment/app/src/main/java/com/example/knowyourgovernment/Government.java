package com.example.knowyourgovernment;

import java.io.Serializable;
import java.util.HashMap;

public class Government implements Serializable {

    private String jobName,servingName;
    private HashMap<String, String> channel = new HashMap<>();
    private String address,party,phones,urls,emails,photoUrl;

    public  Government(){ }
    public Government(String jobName, String servingName){
        this.jobName = jobName;
        this.servingName = servingName;
    }

    public String getJobName() {
        return jobName;
    }

    public String getServingName() {
        return servingName;
    }
    public String getAddress(){
        return address;
    }
    public void setAddress(String address){
        this.address = address;
    }
    public String getEmails() {
        return emails;
    }
    public void setEmails(String emails) {
        this.emails = emails;
    }
    public void setParty(String party) {
        this.party = party;
    }
    public String getParty() {
        return party;
    }

    public String getPhones() {
        return phones;
    }

    public void setPhones(String phones) {
        this.phones = phones;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public String getUrls() {
        return urls;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }

    public void setUrls(String urls) {
        this.urls = urls;
    }

    public HashMap<String, String > getChannel() {
        return channel;
    }

    public void setChannel(String key, String value) {
        channel.put(key,value);
    }
}
