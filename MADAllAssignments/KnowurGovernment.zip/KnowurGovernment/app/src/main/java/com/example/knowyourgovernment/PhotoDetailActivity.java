package com.example.knowyourgovernment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Layout;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class PhotoDetailActivity extends AppCompatActivity {

    TextView role, personName,locationDetail;
    ImageView personOfficialImage,logoDetail;
    ConstraintLayout layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo_detail);

        role = findViewById(R.id.role);
        personName = findViewById(R.id.nameofperson);
        personOfficialImage = findViewById(R.id.personPhoto);
        locationDetail = findViewById(R.id.locationDetail);
        layout = findViewById(R.id.layout);
        logoDetail = findViewById(R.id.logoDetail);


        Intent intent = getIntent();
        if (intent.hasExtra(Intent.ACTION_CALL)) {
            Government g_object = (Government) intent.getSerializableExtra(Intent.ACTION_CALL);

            String url = g_object.getPhotoUrl();
            if (url == null) {
                personOfficialImage.setImageDrawable(getDrawable(R.drawable.missing));
            }
            if (MainActivity.checkNetwork(this)){
                Picasso picasso = new Picasso.Builder(this).build();
                picasso.load(url).error(R.drawable.missing).placeholder(R.drawable.placeholder).into(personOfficialImage);
            }

            else {
                Picasso picasso = new Picasso.Builder(this).build();
                picasso.load(url).error(R.drawable.brokenimage).placeholder(R.drawable.placeholder).into(personOfficialImage);
            }

            role.setText(g_object.getJobName());
            personName.setText(g_object.getServingName());

            String checkParty = g_object.getParty();
            if (checkParty.contains("Democratic")){
                logoDetail.setImageDrawable(getDrawable(R.drawable.dem_logo));
                layout.setBackgroundColor(Color.BLUE);
            }
            else if (checkParty.contains("Republican")){
                logoDetail.setImageDrawable(getDrawable(R.drawable.rep_logo));
                layout.setBackgroundColor(Color.RED);
            }
            else {
                layout.setBackgroundColor(Color.BLACK);
            }
        }

        if (intent.hasExtra(Intent.EXTRA_REFERRER)){
            String location = intent.getStringExtra(Intent.EXTRA_REFERRER);
            locationDetail.setText(location);
        }
    }

}