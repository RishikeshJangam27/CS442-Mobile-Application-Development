package com.example.knowyourgovernment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.accounts.Account;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.net.Inet4Address;
import java.util.ArrayList;
import java.util.Locale;
import static android.content.pm.PackageManager.PERMISSION_GRANTED;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private RecyclerView recyclerView;
    private GovernmentAdapter governmentAdapter;
    private ArrayList<Government> governmentList = new ArrayList<>();
    private TextView location;
    private static int MY_LOCATION_REQUEST_CODE_ID = 329;
    private LocationManager locationManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerview);
        location = findViewById(R.id.location);
        //location.setText("Chicago,IL,60616");
        governmentAdapter = new GovernmentAdapter(this, governmentList);
        recyclerView.setAdapter(governmentAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));




        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (!hasLocation()) {
            askLocationAccess();
        }
    }

    protected void onResume() {
        super.onResume();
        String addLocation = "null";
        if (hasLocation()) {
            addLocation = getLocation();
        }

        if (addLocation.equals("null"))
            return;

        if (!governmentList.isEmpty())
            return;
        loadOfficials(addLocation);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == MY_LOCATION_REQUEST_CODE_ID){
            if (permissions[0].equals(Manifest.permission.ACCESS_FINE_LOCATION) && grantResults[0] == PERMISSION_GRANTED){
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
            }
            else
                location.setText("Location access Cancelled");
        }
    }

    public boolean hasLocation()
        {
            return ContextCompat.checkSelfPermission(
                    this, Manifest.permission.ACCESS_FINE_LOCATION) == PERMISSION_GRANTED ;
        }
        public void askLocationAccess()
        {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION
                    },
                    MY_LOCATION_REQUEST_CODE_ID);
        }
        @SuppressLint("MissingPermission")
        private String getLocation()
        {
            String bestProvider = "network";
            Location currentLocation = locationManager.getLastKnownLocation(bestProvider);
            if (currentLocation == null)
                currentLocation = new Location(bestProvider);

            // Location permission ok but GPS not activated
            if( (currentLocation == null) || (currentLocation.getLatitude()==0.0 && currentLocation.getLongitude()==0.0) )
                return "null";
            else
            {
                return String.format(Locale.getDefault(),"%.4f, %.4f",
                        currentLocation.getLatitude(),currentLocation.getLongitude());
            }
        }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.help:
                Intent intent = new Intent(this, AboutActivity.class);
                startActivity(intent);
                break;
            case R.id.search:

                if (checkNetwork(this))
                {
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    final EditText editText = new EditText(this);
                    editText.setInputType(InputType.TYPE_CLASS_TEXT);
                    editText.setInputType(Gravity.CENTER);
                    editText.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                    builder.setView(editText);
                    editText.getText().toString();

                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            new AsyncDataDownload(MainActivity.this, governmentList, editText.getText().toString()).execute();

                        }
                    });
                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    builder.setTitle("Enter Location/Zipcode:");
                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();

                }
                else
                {
                    noNetwork();
                }

            default:
                break;

        }
        return true;
    }

    @Override
    public void onClick(View v) {
        int position = recyclerView.getChildLayoutPosition(v);
        Government government = governmentList.get(position);
        String loc = location.getText().toString();

        Intent intent = new Intent(this, OfficialActivity.class);
        intent.putExtra(Intent.EXTRA_REFERRER,loc);
        intent.putExtra(Intent.ACTION_CALL, government);
        intent.putExtra("IntentLocation",location.getText().toString());
        startActivity(intent);

    }

    public void postAsync(String loc)
    {
        governmentAdapter.notifyDataSetChanged();
        location.setText(loc);
    }

    static boolean checkNetwork(Context context){
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo != null){
            return networkInfo.isConnected();
        }
        else{
            return false;
        }

    }

    private void loadOfficials(String location){
        if (checkNetwork(this)){
            new AsyncDataDownload(this,governmentList,location).execute();
        }
        else
            noNetwork();
    }

    private void noNetwork(){
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("No Internet Connection");
        alert.setMessage("Turn on Internet");

        AlertDialog dialog = alert.create();
        dialog.show();
    }


}


