package com.example.knowyourgovernment;

import android.net.Uri;
import android.os.AsyncTask;
import android.util.JsonReader;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

class AsyncDataDownload extends AsyncTask<Void, Void,String> {
    private MainActivity mainActivity;
    private ArrayList<Government> governmentArrayList;
    private String location;

    AsyncDataDownload(MainActivity mainActivity, ArrayList<Government> governmentArrayList, String location){
        this.mainActivity = mainActivity;
        this.governmentArrayList = governmentArrayList;
        this.location = location;

    }

    @Override
    protected String doInBackground(Void... voids) {
        String begin = "https://www.googleapis.com/civicinfo/v2/representatives?key=" ;
        String address = "&address="+location;
        String  url = begin + mainActivity.getApplicationContext().getString(R.string.Key) + address;
        String location = null;

        JSONObject jsonObject = downloadData(url);
        if (jsonObject == null){
            return null;
        }
        else {
            governmentArrayList.clear();
            location = DataParser(jsonObject);
            return location;
        }
    }

    @Override
    protected void onPostExecute(String location) {
        mainActivity.postAsync(location);
    }

    private JSONObject downloadData(String url){
        JSONObject jsonObject = null;
        String formatted_url = Uri.parse(url).toString();

        try {
            java.net.URL urlToUse = new URL(formatted_url);
            HttpURLConnection conn = (HttpURLConnection) urlToUse.openConnection();

            if (conn.getResponseCode() != HttpURLConnection.HTTP_OK)
                throw (new Exception());

            conn.setRequestMethod("GET");

            InputStream is = conn.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));
            String line;
            StringBuilder sb = new StringBuilder();

            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
            jsonObject = new JSONObject(sb.toString());
            return jsonObject;
        }
        catch (Exception e) {
            e.printStackTrace();
            return jsonObject;
        }
    }

    private String DataParser(JSONObject jsonObject){
        JSONObject normalizedInput;
        String location = null;
        try {
            normalizedInput = jsonObject.getJSONObject("normalizedInput");
            String city,state,zip;
            city = normalizedInput.getString("city");
            state = normalizedInput.getString("state");
            zip = normalizedInput.getString("zip");
            location = city + ", " + state + ", " + zip;

            JSONArray offices = jsonObject.getJSONArray("offices");
            for (int i = 0; i < offices.length(); ++i) {
                JSONObject office = offices.getJSONObject(i);
                String officename = office.getString("name");

                JSONArray officialindices = office.getJSONArray("officialIndices");

                for (int j = 0; j < officialindices.length(); ++j) {

                    int index = officialindices.getInt(j);
                    JSONArray officials = jsonObject.getJSONArray("officials");
                    JSONObject off = officials.getJSONObject(index);
                    String name = off.getString("name");
                    Government government = new Government(officename, name);

                    if (! off.isNull("address")) {
                        JSONObject address = off.getJSONArray("address").getJSONObject(0);
                        String line2=" ",line3=" ";
                        String line1 = address.getString("line1");
                        if (! address.isNull("line2")){
                            line2 = address.getString("line2");
                        }
                        if (! address.isNull("line3")){
                            line3 = address.getString("line3");
                        }

                        String city1 = address.getString("city");
                        String state1 = address.getString("state");
                        String zip1 = address.getString("zip");
                        government.setAddress(line1 + " " + line2 + " " + line3+" "+city1+" "+state1+" "+" "+zip1);
                    }
                    if (!off.isNull("party")){
                         government.setParty( off.getString("party"));
                    }
                    if (!off.isNull("phones")) {
                        government.setPhones(off.getJSONArray("phones").getString(0));
                    }
                    if (!off.isNull("urls")){
                    government.setUrls(off.getJSONArray("urls").getString(0));
                    }
                    if (!off.isNull("emails")){
                        government.setEmails(off.getJSONArray("emails").getString(0));
                    }
                    if (!off.isNull("photoUrl")) {
                        government.setPhotoUrl(off.getString("photoUrl"));
                    }
                    if (! off.isNull("channels")) {
                        JSONArray channels = off.getJSONArray("channels");
                        for (int k = 0; k < channels.length(); ++k){
                            JSONObject channelObject = channels.getJSONObject(k);
                            government.setChannel(channelObject.getString("type"),channelObject.getString("id"));
                        }
                    }

                    governmentArrayList.add(government);
                }

            }


        } catch (JSONException e) {
            e.printStackTrace();
        }
        return location;
    }


}
