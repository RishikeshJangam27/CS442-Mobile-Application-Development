package com.example.knowyourgovernment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class GovernmentAdapter extends RecyclerView.Adapter<ListViewHolder> {
    private MainActivity mainActivity;
    private ArrayList<Government> governmentList;
    private static final String TAG = "RISHI_GovernmentAdapter";

    public GovernmentAdapter(MainActivity mainActivity, ArrayList<Government> governmentList){
        this.mainActivity = mainActivity;
        this.governmentList = governmentList;
    }

    @NonNull
    @Override
    public ListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Log.d(TAG, "onCreateViewHolder: ");
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.government_list,parent,false);
        view.setOnClickListener(mainActivity);
        return new ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ListViewHolder holder, int position) {
        Log.d(TAG, "onBindViewHolder: ");
        Government government = governmentList.get(position);
        holder.jobName.setText(government.getJobName());
        holder.servingName.setText(government.getServingName());

    }

    @Override
    public int getItemCount() {
        return governmentList.size();
    }
}
