package com.example.knowyourgovernment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.util.Linkify;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.HashMap;

public class OfficialActivity extends AppCompatActivity {
    private TextView jobOfficial, personNameOfficial, partyNameOfficial,locationOfficial;
    private ImageView personOfficialImage,logo;
    private ScrollView scrollView;
    private LinearLayout linearLayout;


    private static final String TAG = "rishi_OfficialActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_official);

        jobOfficial = findViewById(R.id.jobOfficial);
        personNameOfficial = findViewById(R.id.personNameOfficial);
        partyNameOfficial = findViewById(R.id.partyNameOfficial);
        personOfficialImage = findViewById(R.id.personOfficialImage);
        locationOfficial = findViewById(R.id.locationOfficial);
        scrollView = findViewById(R.id.scrollview);
        linearLayout = findViewById(R.id.linearLayout);
        logo = findViewById(R.id.logo);



        Intent intent = getIntent();

        if (intent.hasExtra("Location")){
            locationOfficial.setText(intent.getStringExtra("Location"));
        }


        if(intent.hasExtra(Intent.ACTION_CALL)){
            Government g_object = (Government) intent.getSerializableExtra(Intent.ACTION_CALL);
            TextView textView;

            //url

            if (g_object.getUrls() != null){
                textView = new TextView(this);
                textView.setText("Website:  ".concat(g_object.getUrls()).concat("\n") );
                textView.setTextSize(20);
                Linkify.addLinks(textView,Linkify.ALL);
                textView.setTextColor(Color.WHITE);
                linearLayout.addView(textView);
            }
           //address
            if (g_object.getAddress() != null){
                textView = new TextView(this);
                textView.setText("Address:  ".concat(g_object.getAddress()).concat("\n") );
                textView.setTextSize(20);
                Linkify.addLinks(textView,Linkify.MAP_ADDRESSES);
                textView.setTextColor(Color.WHITE);
                linearLayout.addView(textView);
            }

            //email
            if (g_object.getEmails() != null){
                textView = new TextView(this);
                textView.setText("Email:   ".concat(g_object.getEmails()).concat("\n") );
                textView.setTextSize(20);
                textView.setTextColor(Color.WHITE);
                Linkify.addLinks(textView,Linkify.ALL);
                linearLayout.addView(textView);
            }
            //phone
            if (g_object.getPhones() != null){
                textView = new TextView(this);
                textView.setText("Phone:   ".concat(g_object.getPhones()).concat("\n") );
                textView.setTextSize(20);
                textView.setTextColor(Color.WHITE);
                Linkify.addLinks(textView,Linkify.PHONE_NUMBERS);
                linearLayout.addView(textView);
            }

            //channels

            if (g_object.getChannel() != null){
                HashMap<String, String> channels = g_object.getChannel();
                ImageView imageView = null;
                int index = 0;
                for(final String key : channels.keySet()){
                    switch (index)
                    {
                        case 0:
                            imageView = findViewById(R.id.social1);
                            break;
                        case 1:
                            imageView = findViewById(R.id.social2);
                            break;
                        case 2:
                            imageView = findViewById(R.id.social3);
                            break;
                        case 3:
                            imageView = findViewById(R.id.social4);
                            break;
                    }
                    ++index;

                    final String keyv = channels.get(key);
                    switch (key){
                        case "GooglePlus":
                            imageView.setImageDrawable(getDrawable(R.drawable.googleplus));
                            imageView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    googlePlusClicked(v,keyv);
                                }
                            });
                            break;
                        case "Facebook":
                            imageView.setImageDrawable(getDrawable(R.drawable.facebook));
                            imageView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    facebookClicked(v,keyv);
                                }
                            });
                            break;
                        case "Twitter":
                            imageView.setImageDrawable(getDrawable(R.drawable.twitter));
                            imageView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    twitterClicked(v,keyv);
                                }
                            });
                            break;
                        case "YouTube":
                            imageView.setImageDrawable(getDrawable(R.drawable.youtube));
                            imageView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                youTubeClicked(v,keyv);
                                }
                            });
                            break;
                    }

                }

            }

            String url = g_object.getPhotoUrl();
            if(url == null){
                personOfficialImage.setImageDrawable(getDrawable(R.drawable.missing));
            }

            //if (MainActivity.checkNetwork(this)){
              // Picasso picasso = new Picasso.Builder(this).build();
              // picasso.load(url).error(R.drawable.missing).placeholder(R.drawable.placeholder).into(personOfficialImage);
            //}
            else {
                Log.d(TAG, "onCreate: "+url);
                Picasso picasso = new Picasso.Builder(this).build();
                picasso.load(url).error(R.drawable.brokenimage).placeholder(R.drawable.placeholder).into(personOfficialImage);
            }

            jobOfficial.setText(g_object.getJobName());
            personNameOfficial.setText(g_object.getServingName());
            partyNameOfficial.setText(g_object.getParty());
            if (partyNameOfficial.getText().toString().contains("Democratic")){
                logo.setImageDrawable(getDrawable(R.drawable.dem_logo));
                scrollView.setBackgroundColor(Color.BLUE);
            }
            else if (partyNameOfficial.getText().toString().contains("Republican")){
                logo.setImageDrawable(getDrawable(R.drawable.rep_logo));
                scrollView.setBackgroundColor(Color.RED);
            }
            else {
                scrollView.setBackgroundColor(Color.BLACK);
            }

        }
        if (intent.hasExtra(Intent.EXTRA_REFERRER)){
            String location = intent.getStringExtra(Intent.EXTRA_REFERRER);
            locationOfficial.setText(location);
        }
    }


    public void twitterClicked(View v, String keyv) {
        Intent intent = null;
        String name = keyv;
        try {
            // get the Twitter app if possible
            getPackageManager().getPackageInfo("com.twitter.android", 0);
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("twitter://user?screen_name=" + name));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        } catch (Exception e) {
            // no Twitter app, revert to browser
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/" + name));
        }
        startActivity(intent);
    }


    public void facebookClicked(View v,String keyv) {
        String FACEBOOK_URL = "https://www.facebook.com/" + keyv;
        String urlToUse;
        PackageManager packageManager = getPackageManager();
        try {
            int versionCode = packageManager.getPackageInfo("com.facebook.katana", 0).versionCode;
            if (versionCode >= 3002850) { //newer versions of fb app
                urlToUse = "fb://facewebmodal/f?href=" + FACEBOOK_URL;
            } else { //older versions of fb app
                urlToUse = "fb://page/" + keyv;
            }
        } catch (PackageManager.NameNotFoundException e) {
            urlToUse = FACEBOOK_URL; //normal web url
        }
        Intent facebookIntent = new Intent(Intent.ACTION_VIEW);
        facebookIntent.setData(Uri.parse(urlToUse));
        startActivity(facebookIntent);
    }

    public void googlePlusClicked(View v, String keyv) {
        String name = keyv;
        Intent intent = null;
        try {
            intent = new Intent(Intent.ACTION_VIEW);
            intent.setClassName("com.google.android.apps.plus",
                    "com.google.android.apps.plus.phone.UrlGatewayActivity");
            intent.putExtra("customAppUri", name);
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://plus.google.com/" + name)));
        }
    }

       public void youTubeClicked(View v, String keyv) {
            String name = keyv;
            Intent intent = null;
            try {
                intent = new Intent(Intent.ACTION_VIEW);
                intent.setPackage("com.google.android.youtube");
                intent.setData(Uri.parse("https://www.youtube.com/" + name));
                startActivity(intent);
            } catch (ActivityNotFoundException e) {
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://www.youtube.com/" + name)));
            }
        }


    public void onClick(View view)
    {
        Intent obj = getIntent();
        Government g_object = (Government) obj.getSerializableExtra(Intent.ACTION_CALL);
        if (g_object.getPhotoUrl() == null)
            return;
        String location = obj.getStringExtra(Intent.EXTRA_REFERRER);
        Intent intent = new Intent(this,PhotoDetailActivity.class);
        intent.putExtra(Intent.ACTION_CALL, g_object);
        intent.putExtra(Intent.EXTRA_REFERRER,location);
        startActivity(intent);
    }

    public void logoClick(View view){
        if (partyNameOfficial.getText().toString().contains("Democratic")){
            String url = "https://democrats.org";
            Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse(url));
            startActivity(intent);
        }

        else if (partyNameOfficial.getText().toString().contains("Republican")){
            String url = "https://www.gop.com";
            Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse(url));
            startActivity(intent);

        }
    }


}


