package com.example.distanceconverter;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;
import java.lang.*;
import android.text.method.ScrollingMovementMethod;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    public double result, input2;
    public String input1 = "", str= " ";
    private EditText input;
    private TextView output, milevalue, kmvalue, history;
    private RadioGroup rg;
    private RadioButton rb1, rb2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        input = findViewById(R.id.editText);
        output = findViewById(R.id.textView6);
        milevalue = findViewById(R.id.textView2);
        kmvalue = findViewById(R.id.textView3);
        history = findViewById(R.id.textView5);
        rb1 = findViewById((R.id.radioButton1));
        rb2 = findViewById(R.id.radioButton2);
        rg = findViewById(R.id.radioGroup);

    }


    public void distanceConvert(View v) {


        input1 = input.getText().toString();

        if(input1.isEmpty())
            Toast.makeText(this,"Enter miles to Convert", Toast.LENGTH_SHORT).show();

        else
        {
            try {
                input2 = Double.parseDouble(input1);
            } catch (Exception e) {

                Toast.makeText(this, "Enter Number", Toast.LENGTH_SHORT).show();
            }

            int currentid = rg.getCheckedRadioButtonId();
            if (currentid == rb1.getId()) {

                result = input2 *1.60934;
                output.setText(String.format("% .1f", result));
                str = input1 + " Mi" + " = " + String.format("% .1f", result) + " Km" + "\n" + str;
            }
            else {
                result = input2 * 0.621371 ;
                output.setText(String.format("%.1f", result));
                str = input1 + " Km" + " = " + String.format("% .1f", result) + " Mi" + "\n" + str;


            }

            history.setMovementMethod(new ScrollingMovementMethod());
            history.setText(str);
        }


    }

    public void radioButton(View v)
    {
        int currentid = rg.getCheckedRadioButtonId();


        if(currentid == rb1.getId()) {
            milevalue.setText("Miles to Kilometers:");
            kmvalue.setText("Kilometers to Miles:");
        }

        else if(currentid == rb2.getId()) {
            milevalue.setText("Miles to Kilometers:");
            kmvalue.setText("Kilometers to Miles:");

        }

    }

    public void clear(View v) {
        str = "";
        history.setText("");
    }

    @Override
    protected void onSaveInstanceState(Bundle outState)
    {
        outState.putString("History",history.getText().toString());
        outState.putString("Output",output.getText().toString());
        outState.putString("MtoK",milevalue.getText().toString());
        outState.putString("KtoM",kmvalue.getText().toString());
        outState.putString("str",str);

        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {

        super.onRestoreInstanceState(savedInstanceState);

        history.setText(savedInstanceState.getString("History"));
        output.setText(savedInstanceState.getString("Output"));
        milevalue.setText(savedInstanceState.getString("MtoK"));
        kmvalue.setText(savedInstanceState.getString("KtoM"));
        str = savedInstanceState.getString("str");

    }


}
